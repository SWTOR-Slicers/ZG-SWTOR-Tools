import bpy

# rename selected objects and materials to make adding characters to a scene
# less confusing and prone to errors. Use as convention a hyphen as separator
# to make other material processing scripts' lives easier.
# Investigate using custom properties to store original data.