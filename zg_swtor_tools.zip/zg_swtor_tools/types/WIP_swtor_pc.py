class swtor_pc:
    
    # Basic 
    
    
    
    
    
    # slots
    appSlotAge:         int = 1
    appSlotComplexion:  int = 1
    appSlotEyeColor:    int = 1
    appSlotFaceHair:    int = 1
    appSlotFacePaint:   int = 1
    appSlotHair:        int = 1
    appSlotHairColor:   int = 1
    appSlotHead:        int = 1
    appSlotSkinColor:   int = 1



    # ui
    wdg_faction:    str = "Empire"
    wdg_class:      str = "Sith Warrior"
    wdg_species:    str = "Human"
    wdg_gender:     str = "Female"
    wdg_bodytype:   int = 1

    wdg_Head:       int = 6
    wdg_Age:        int = 3
    wdg_Complexion: int = 2
    wdg_EyeColor:   int = 4
    wdg_FaceHair:   int = 3
    wdg_FacePaint:  int = 3
    wdg_Hair:       int = 5
    wdg_HairColor:  int = 3
    wdg_SkinColor:  int = 6


    